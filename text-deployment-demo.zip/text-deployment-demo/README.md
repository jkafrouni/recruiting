# text-deployment-demo
Showing how to use Watson Studio Local and Watson Machine Learning to build NLP models for production.
